import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import org.dom4j.DocumentException;

public class Main {

	/**
	 * @param args
	 * @throws ParseException 
	 * @throws DocumentException 
	 * @throws UnknownHostException 
	 * @throws RemoteException 
	 * @throws ServiceException 
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws UnknownHostException, DocumentException, ParseException, RemoteException, ServiceException, MalformedURLException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// 通过jar包调用X5Action
		X5Actions actions = new X5Actions();
		String actionResult = actions.startBorrowBook("四世同堂（API调用方式）",  sdf.parse("2012-12-01"), sdf.parse("2012-12-31"), "王五");
		System.out.println("通过jar包调用X5 Action成功 -> " + actionResult);
		/*
		 */

		// 调用测试WebService
		/*
		Object[] testParams = {51, 6};
		Object testResult = invokeService("http://localhost:8080/axis/Test.jws", "http://localhost:8080/axis/Test.jws", "sum", testParams);
		System.out.println("调用测试WebService成功 -> " + testResult);
		
		// 通过wsdl生成java的调用 java org.apache.axis.wsdl.WSDL2Java -o src -p demo http://localhost:8080/axis/Test.jws?wsdl
		demo.TestServiceLocator service = new demo.TestServiceLocator();
		demo.TestSoapBindingStub test = (demo.TestSoapBindingStub) service.getTest();
		// test.setUsername(username);
		// test.setPassword(password);
		System.out.println(test.sum(10, 6));

		// 调用X5Action WebService
		Object[] x5Params = {"四世同堂（Web Service调用方式）",  sdf.parse("2012-12-01"), sdf.parse("2012-12-31"), "王五"};
		Object x5Result = invokeService("http://localhost:8080/axis/X5Actions.jws", "http://localhost:8080/axis/X5Actions.jws", "startBorrowBook", x5Params);
		System.out.println("调用X5Action WebService成功 -> " + x5Result);
		 */
		
	}
	
	public static Object invokeService(String namespace, String address, String operation, Object[] params) throws MalformedURLException, RemoteException, ServiceException {
		// 调用WebService
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		org.apache.axis.client.Call call = (org.apache.axis.client.Call) service.createCall();
		call.setOperationName(new QName(namespace, operation));
		call.setTargetEndpointAddress(new java.net.URL(address));

		return call.invoke(params);
	}

}
