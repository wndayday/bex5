import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.Date;
import java.util.TimerTask;

import org.dom4j.DocumentException;

public class DemoTask extends TimerTask {
	public void doSomething() throws UnknownHostException, DocumentException, ParseException {
		System.out.println("定时任务：" + new Date());

		// 调用动作
//		X5Actions action = new X5Actions();
//		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
//		action.startBorrowBook("定时借书", sdf.parse("2012-12-21"), sdf.parse("2013-12-21"), "李明明");
	}

	public void run() {
		try {
			doSomething();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
