
import java.net.UnknownHostException;

import com.justep.biz.client.Action;
import com.justep.biz.client.ActionEngine;
import com.justep.biz.client.ActionResult;
import com.justep.biz.client.ActionUtils;

public class X5Actions {
	public String login() throws UnknownHostException {
		String businessServer = "http://127.0.0.1:8080/BusinessServer";
		String loginName = "system";
		String password = "123456";
		
		// 获得本地IP地址
		String localIP = java.net.InetAddress.getLocalHost().getHostAddress();
		// 初始化动作引擎
		ActionEngine.init(businessServer);
		// 登录
		String bSessionID = ActionEngine.login(loginName, ActionUtils.md5(password), localIP, null);
		// 返回bSessionID
		return bSessionID;
	}
	
	public String startBorrowBook(String bookName, java.util.Date startDate, java.util.Date endDate, String borrower) throws UnknownHostException {
		// 登录
		String bSessionID = login();
		try {
			Action action = new Action();
			// 指定动作的process、activity和action，这里要注意登录的用户应该有执行这个功能中的这个动作的权限
			action.setProcess("/demo/actions/process/integration/integrationProcess");
			action.setActivity("staticActivity1");
			action.setName("startBorrowBook");
			// 设置动作参数
			action.setParameter("bookName", bookName);
			action.setParameter("startDate",  new java.sql.Date(startDate.getTime()));
			action.setParameter("endDate", new java.sql.Date(endDate.getTime()));
			action.setParameter("borrower", borrower);
			
			// 调用动作
			ActionResult actionResult = ActionEngine.invokeAction(action, ActionUtils.JSON_CONTENT_TYPE, bSessionID, null, null);
			
			// 判断是否调用成功
			if (actionResult.isSuccess()){
				// 返回值
				return actionResult.getDatas().get(0).toString();
			} else {
				throw new RuntimeException(actionResult.getMessage());
			}
		} finally {
			// 要保证注销，否则会占用在线人数
			ActionEngine.logout(bSessionID);
		}
	}
	
}
