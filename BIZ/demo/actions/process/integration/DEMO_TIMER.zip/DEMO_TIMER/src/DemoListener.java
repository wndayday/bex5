import java.util.Date;
import java.util.Timer;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class DemoListener implements ServletContextListener {

	private Timer timer = new Timer();
	
	public void contextDestroyed(ServletContextEvent event) {
		timer.cancel();
	}

	public void contextInitialized(ServletContextEvent event) {
		Date firstTime = new Date(System.currentTimeMillis());
		int period = 60;
		// 设置定时的开始时间和周期
		timer.schedule(new DemoTask(), firstTime, period * 1000);
	}

}
