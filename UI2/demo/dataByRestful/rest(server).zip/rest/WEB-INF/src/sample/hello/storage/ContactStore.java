package sample.hello.storage;

import java.util.LinkedHashMap;
import java.util.Map;

import sample.hello.bean.Contact;

public class ContactStore {
	private static Map<String,Contact> store;
	private static ContactStore instance = null;
	
	private ContactStore() {
		store = new LinkedHashMap<String,Contact>();
		initContacts();
	}
	
	public static Map<String,Contact> getStore() {
		if(instance==null) {
			instance = new ContactStore();
		}
		return store;
	}
	
	private static void initContacts() {
		for(int i=1;i<=100;i++){
			Contact c = new Contact("id"+i, "Huang_"+i);
			store.put(c.getId(), c);
		}
	}
}
