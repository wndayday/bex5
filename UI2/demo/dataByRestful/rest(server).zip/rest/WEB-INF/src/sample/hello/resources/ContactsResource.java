package sample.hello.resources;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBElement;

import sample.hello.bean.Contact;
import sample.hello.storage.ContactStore;


@Path("/contacts")
public class ContactsResource {
	
	@Context
	UriInfo uriInfo;
	@Context
	Request request;

	@GET
	@Produces({MediaType.APPLICATION_JSON})
	public List<Contact> getContacts(@QueryParam("offset") String offset, @QueryParam("limit") String limit, @Context HttpServletResponse response) {
		if(null==offset||"".equals(offset)) offset = "0";
		if(null==limit||"".equals(limit)) limit = "-1";
		int iOffset = Integer.parseInt(offset);
		int iLimit = Integer.parseInt(limit);
		List<Contact> contacts = new ArrayList<Contact>();
		Collection<Contact> values = ContactStore.getStore().values();
		if(-1==iLimit)
			contacts.addAll(values);
		else{
			int i=0;
			for(Contact c : values){
				if(i>=iOffset){
					if(i>=iOffset+iLimit) break;
					contacts.add(c);
				}
				i++;
			}
		}
		//当取第一页数据时返回总条数
		if(0==iOffset) response.addHeader("X-Total-Count", getCount());
		return contacts;
	}
	
	@GET
	@Path("count")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCount() {
		int count = ContactStore.getStore().size();
		return String.valueOf(count);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public void newContact(JAXBElement<Contact> jaxbContact){
		Contact c = jaxbContact.getValue();
		ContactStore.getStore().put(c.getId(), c);
	}
	
	@Path("{contact}")
	public ContactResource getContact(
			@PathParam("contact") String contact) {
		return new ContactResource(uriInfo, request, contact);
	}
	
}
